#!/usr/bin/env python3
import MidProjectReview
import subTask1
import mdiffTest

def main():
    MidProjectReview.test()

if __name__ == "__main__":
    main()