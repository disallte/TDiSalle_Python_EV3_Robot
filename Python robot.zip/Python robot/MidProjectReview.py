#!/usr/bin/env python3
import math
from ev3dev2.sensor import INPUT_1, INPUT_2, INPUT_3
from ev3dev2.sound import Sound
from ev3dev2.motor import OUTPUT_A, OUTPUT_B, OUTPUT_C, OUTPUT_D, MoveDifferential, LargeMotor, MoveTank, SpeedRPS, SpeedRPM
from ev3dev2.wheel import EV3Tire
from ev3dev2.sensor.lego import GyroSensor
import time

STUD_MM = 8
largemotorR = 'outA'
largemotorL = 'outD'
bothWheels=MoveTank(largemotorR,largemotorL)
driveSpeed = SpeedRPM(25) #speed of motors for driving
wheel2WheelDiameter = 16 #milimeters
whip = MoveDifferential(largemotorL, largemotorR, EV3Tire,STUD_MM*16)
whip.gyro = GyroSensor(INPUT_1)
sound = Sound()

def test():
    whip.odometry_start(90,0,0)
    whip.gyro.calibrate()
    whip.gyro.reset()
    sound.speak("Life to america")
    for i in range(4):
        whip.on_for_distance(driveSpeed,0.1*1000) #move differential uses milimeter
        whip.gyro.calibrate()
        whip.turn_right(driveSpeed, 180,True,True,2,False)  
        whip.gyro.calibrate()
    bothWheels.turn_degrees(driveSpeed, 360,True, True, 2, True)