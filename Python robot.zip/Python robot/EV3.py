import socket
import struct

class EV3():
    def __init__(self, id:str):
        #bluetooth socket
        self.socket1 = socket.socket(family=socket.AF_BLUETOOTH, proto=socket.BTPROTO_RFCOMM)

        #Connect ev3 to sock
        self.socket1.connect((id,1))

    def __del__(self):
        self.socket1.close()

    def sendCMD(self, cmd):
        return self.socket1.send(cmd)
    
    def formatCMD(self,cmd, reply: bool):
        #reply
        if reply: _reply = '0x/01'
        else: _reply = '0x/81'

        cmd = b''.join(
            self.formatSTR(len(cmd)+5), #length
            self.formatSTR(42),         #COunter
            _reply,                     #Reply
            self.formatSTR(0),          #memory
            cmd                         #cmd
        )

    def formatSTR(self, string):
        return struct.pack('<h', string)