#!/usr/bin/env python3
import math
from ev3dev2.motor import OUTPUT_A, OUTPUT_B, OUTPUT_C, OUTPUT_D, MoveDifferential, LargeMotor, MoveTank, SpeedRPS, SpeedRPM
from ev3dev2.wheel import EV3Tire
import time

STUD_MM = 8
largemotorR = LargeMotor('outA')
largemotorL = LargeMotor('outD')
bothWheels=MoveTank('outA','outD')
wheelRadius = 3.45 #milimeters
driveSpeed = 25 #speed of motors for driving
wheel2WheelDiameter = 12.9 #milimeters
mdiff = MoveDifferential(OUTPUT_A, OUTPUT_D, EV3Tire, wheel2WheelDiameter * STUD_MM)

# move forward then reverse.
def subtask1a(distCM, n):
    rotations = distCM/(2*math.pi*wheelRadius) # number of rotations from cm 
    for i in range(n):
        #forward
        bothWheels.on_for_rotations(driveSpeed,driveSpeed,rotations)
        #reverse
        bothWheels.on_for_rotations(-driveSpeed,-driveSpeed,rotations)
    
def rotate(deg):
    rotations =( (((deg)/360)*(math.pi*wheel2WheelDiameter)) # the distance the wheels must go
               /(2*math.pi*wheelRadius))                     # converted into the rotations of the wheel
    bothWheels.on_for_rotations(driveSpeed, -driveSpeed, rotations)

def subtask1b(distCM, n):
    rotations = distCM/(2*math.pi*wheelRadius)
    for i in range(n):
        #forward
        bothWheels.on_for_rotations(driveSpeed,driveSpeed,rotations)
        #reverse
        rotate(180)
        bothWheels.on_for_rotations(driveSpeed,driveSpeed,rotations)
        #face front soldier
        rotate(180)

#DriveBase

